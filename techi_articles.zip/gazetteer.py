# gazetteer.py
# Builds a list of company names from stock exchange listings and
# uses it to check whether a headline mentions a company.

import csv
import io
import json
import re
import urllib.request

# Where the data comes from: NASDAQ / NYSE / AMEX listings and the S&P 500 list
LISTING_URL = "https://raw.githubusercontent.com/rreichel3/US-Stock-Symbols/main/{0}/{0}_full_tickers.json"
SP500_URL = "https://raw.githubusercontent.com/datasets/s-and-p-500-companies/main/data/constituents.csv"
EXCHANGES = ["nasdaq", "nyse", "amex"]

# Legal words that come after the real name in a listing,
# e.g. "Apple Inc. Common Stock" -> we only want "Apple"
SUFFIX = re.compile(
    r"\b(common stock|common shares?|ordinary shares?|class [a-c]\b.*|american depositary (shares?|receipts?).*|"
    r"depositary shares?.*|each representing.*|ads\b.*|\(.*?\)|new$|"
    r"incorporated|inc|corporation|corp|company|co|ltd|limited|plc|n\.?v|s\.?a|se|ag|holdings?|group|"
    r"lp|l\.p|llc|trust|the)\b\.?",
    re.I,
)

# If the second word of a name is one of these, people usually say only the first word
# ("Micron Technology" -> "Micron", "Meta Platforms" -> "Meta")
GENERIC = {
    "platforms", "technology", "technologies", "energy", "motors", "systems",
    "semiconductor", "semiconductors", "wholesale", "software", "pharmaceuticals",
    "pharmaceutical", "therapeutics", "networks", "industries", "international",
    "enterprises", "financial", "bancorp", "labs", "automotive", "communications",
    "stores", "brands", "entertainment", "interactive", "resources", "solutions",
    "sciences", "health", "digital", "mobile", "electronics", "biosciences",
    "medical", "foods", "airlines", "computer", "robotics", "aerospace", "power",
}


def download(url):
    # some servers reject requests without a browser-like User-Agent
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    response = urllib.request.urlopen(request, timeout=60)
    return response.read().decode("utf-8")


def clean_name(name):
    # drop anything after " - " (listing notes)
    name = name.split(" - ")[0]

    # keep removing suffixes until the name stops changing,
    # because one name can have several ("Inc." then "Common Stock")
    previous = None
    while previous != name:
        previous = name
        name = SUFFIX.sub("", name)
        name = name.strip(" ,.&-")
        name = re.sub(r"\s{2,}", " ", name)   # collapse double spaces left behind
    return name


def build(min_cap_alias=2e9, big_cap=1e11, common_zipf=4.0):
    # wordfreq tells us how common a word is in English (higher = more common).
    # Imported here so the rest of the file works without it installed.
    from wordfreq import zipf_frequency

    # Step 1: download the three exchange listings into one list
    listings = []
    for exchange in EXCHANGES:
        listings += json.loads(download(LISTING_URL.format(exchange)))

    names = set()

    for row in listings:
        # Step 2: skip rows that are not ordinary shares (warrants, units, preferreds
        # have symbols with extra characters)
        symbol = row["symbol"].strip()
        if not re.fullmatch(r"[A-Z]{1,5}", symbol):
            continue

        # Step 3: clean the listing name, ignore very short leftovers
        full = clean_name(row["name"])
        if len(full) < 3:
            continue

        cap = float(row.get("marketCap") or 0)

        # Step 4: add the full name.
        # Exception: a single everyday word ("Unity", "Strategy") would match
        # normal headlines, so only keep it if the company is very large ("Apple").
        is_single_word = " " not in full
        is_common_word = zipf_frequency(full.lower(), "en") >= common_zipf
        if not (is_single_word and is_common_word) or cap >= big_cap:
            names.add(full)

        # Step 5: add a short version of the name when it makes sense
        #   "Micron Technology" -> "Micron"   (second word is generic)
        #   "Amazon.com"        -> "Amazon"   (drop the .com)
        words = full.split(" ")
        first = words[0].replace(".com", "")
        has_generic_second_word = len(words) == 2 and words[1].lower() in GENERIC
        had_dotcom = first != words[0]

        if (has_generic_second_word or had_dotcom) and cap >= min_cap_alias and len(first) >= 3:
            commonness = zipf_frequency(first.lower(), "en")
            # same idea as step 4: common words only allowed for very large companies
            if commonness < common_zipf or (cap >= big_cap and commonness < 5.0):
                names.add(first)

    # Step 6: add the S&P 500 names, which are written the way people say them ("Alphabet")
    sp500 = csv.DictReader(io.StringIO(download(SP500_URL)))
    for row in sp500:
        names.add(row["Security"].split(" (")[0])

    return sorted(names)


def make_matcher(names, extra=()):
    # combine the list with any extra names the user passes in (e.g. "SpaceX")
    all_names = set(names) | set(extra)

    # longest first, so "Applied Materials" is tried before a shorter overlapping name
    all_names = sorted(all_names, key=len, reverse=True)

    # one big pattern: name1|name2|name3...
    # re.escape makes dots etc. literal ("C.H. Robinson")
    alternatives = "|".join(re.escape(n) for n in all_names)

    # the lookbehind/lookahead make sure we match whole words only,
    # so "Meta" does not match inside "Metadata"
    pattern = re.compile(r"(?<![\w.])(" + alternatives + r")(?![\w])")

    def find_companies(headline):
        # returns every company name found, e.g. ["Nvidia", "Tesla"]
        return [m.group(1) for m in pattern.finditer(headline)]

    return find_companies