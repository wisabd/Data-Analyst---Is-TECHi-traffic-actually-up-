methods.txt

This is a project to scrape the first 20 articles from each section of the Techi website.

Requirements:
- Python 3.10
- Selenium
- BeautifulSoup
- Pandas
- Requests
- JSON
- Gazetteer

Files:
- company_gazetteer.json : contains the list of company names
- techi_articles.csv : contains the scraped articles
- gazetteer.py : contains the code to scrape the articles
- README.md


How to run the code:
- Download the code from the repository and save all files in a folder
- Run the techi_first_article.ipynb file to scrape the articles, and build techi_articles.csv on your own.
- Gazetter.py is run from within the jupyter notebook to load check if article contains a company name. 
- Run the techi_articles.csv file to save the articles

Main decisions:
- Used Selenium to scrape the articles because it is a dynamic website and the articles are loaded dynamically as you scroll down the page.
- Split the article format into 3 categories: news/analysis, forecast, and comparison.
- Implemented Gazetteer.py to check if the article contains a company name, it performs better than SpaCy.






